function selectButtons(element) {
	var buttons = document.getElementById("buttonGroup").getElementsByClassName("button");
	for (var i = 0; i < buttons.length; i++) {
		buttons[i].addEventListener("click", function() {
			var currentButton = document.getElementsByClassName("active");
			if (currentButton.length > 0) { 
				currentButton[0].className = currentButton[0].className.replace(" active", "");
			}
			this.className += " active";
		});			
	}
}
function displayText(element) {
	var textFileReader = new FileReader();
	if (element.Id == "Personal information") {
		element.textContent = element.textContent = textFileReader.readAsText("text_files/Personal_information.txt");
	} else if (element.Id == "Work experience") {
		element.textContent = element.textContent = textFileReader.readAsText("text_files/Work_experience.txt");
	} else if (element.Id == "Education and trainings") {
		element.textContent = element.textContent = textFileReader.readAsText("text_files/Education_and_trainings.txt");
	} else {		
		element.textContent = textFileReader.readAsText("text_files/Personal_skills.txt");
	}
}