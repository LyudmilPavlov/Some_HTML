function highlightButton() {
    var buttonGroup = document.getElementById("buttonGroup");
	var buttons = buttonGroup.getElementsByClassName("button");
	for (var i = 0; i < buttons.length; i++) {
        buttons[i].addEventListener("click", function() {
            var currentButton = document.getElementsByClassName("active");
            if (currentButton.length > 0) { 
		      currentButton[0].className = currentButton[0].className.replace(" active", "");
            }
            this.className += " active";
        });
    }
}
		
function displayText(element) {
	if (element == "personal") {
        document.getElementById('textField').innerHTML =
            '<section>\
                <h3>Lyudmil Marianov Pavlov</h3>\
                <p>\
                    <img src="icons/location.jpg" style="float:center;width:25px;height:25px;">\
                    1303, Sofia, Zone B-5, block 14, ent. A, floor 7, apt. 83\
                </p>\
                <p>&#9742  00359878972732</p>\
                <p>\
                    <img src="icons/email.png" style="float:center;width:26px;height:26px;">\
                    liudmilpavlov@gmail.com\
                </p>\
                <img src="icons/linkedin.png" style="float:center;width:23px;height:23px;">\
                <a href="https://www.linkedin.com/in/lyudmil-pavlov-1b9ba732" target="_blank">https://www.linkedin.com/in/lyudmil-pavlov-1b9ba7</a>\
                <p>Sex: MALE | Date of birth: 09/02/1980 | Nationality: Bulgaria</p>\
            </section>';
	} else if (element == "experience") {
        document.getElementById('textField').innerHTML =
            '<section>\
                <h3><b>10.09.2018 - present</b></h3>\
                <p>DevOps at SAP Labs Ltd. Bulgaria.<br>\
                Automating processes related to SAP Cloud platform.</p>\
                <h3><b>18.08.2014 – 07.09.2018</b></h3>\
                <p>Second tier of JEE Web & Middleware Technical Support Engineer at DXC.technology(former Hewlett-Packard Enterprise)</br>\
                Focused on support of Middleware technologies and products such as: Apache, Tomcat,IBM WebSphere, Oracle WebLogic and IBM MQ, running on Linux environments – mostly RHEL.<br>\
                Duties included software changes implementation, incident management, problem management and knowledge management.</p>\
                <h3><b>01.11.2002 - 18.08.2014</b></h3>\
                <p>Investigation policeman at Ministry of interior – Bulgaria</p>\
            </section>';
	} else if (element == "education") {
		document.getElementById('textField').innerHTML =
            '<section>\
                <h3><b>2013</b></h3>\
                <p>“Introduction to SQL” course at centre for professional education “Devise Expert” – Sofia</p>\
                <h3><b>2012 – 2013</b></h3>\
                <p>Course in programming with Java at educational centre “SoftAcad” – Sofia. Concepts of OOP, variables, methods, etc.</p>\
                <h3><b>2011 – 2012</b></h3>\
                <p>CCNA course “CCNA Exploration: Routing protocols and concepts” at Bulgarian Industrial Association.</p>\
                <h3><b>2003 – 2007</b></h3>\
                <p>Magister in Law at South-west university “Neofit Rilsky”.</p>\
                <h3><b>1998 – 2002</b></h3>\
                <p>Academy of Ministry of interior – Bulgaria.</p>\
            </section>';
	} else {		
		document.getElementById('textField').innerHTML =
            '<section>\
                <h3><b>Soft skills</b></h3>\
                <p>Self driven and motivated<br>\
                Friendly and open-minded<br>Punctual<br>\
                Communicative<br>Responsible<br>\
                Adaptable<br></p>\
            </section>\
            <section>\
                <h3><b>Programming languages</b></h3>\
                <p>Minor experience with Java, Python and HTML<br>\
                Tasted JavaScript, Ruby, C, CSS and even Visual Basic<br></p>\
            </section>\
            <section>\
                <h3><b>Other technologies</b></h3>\
                <p>Intermediate experience with Jenkins<br>\
                Intermediate skill in Bash scripting<br>\
                Basic knowledge in Ansible<br>\
                Good knowledge of Linux<br>\
                Basic experience and knowledge of Docker<br></p>\
            </section>\
            <section>\
                <h3><b>GitHub project in Jenkins Bash automation</b></h3>\
                <a href="https://github.com/LyudmilPavlov/ICA_update.git" target="_blank">https://github.com/LyudmilPavlov/ICA_update.git</a>\
            </section>';
	}
}








